/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import DAO.AddressDao;
import DAO.BookDao;
import DAO.LoanDao;
import DAO.MemberDao;
import DTO.Address;
import DTO.Book;
import DTO.Loan;
import DTO.Member;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Audrius
 * @author Tom
 * @author Ahmed
 */
public class LibraryApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        MemberDao memberDao = new MemberDao("library");
        BookDao bookDao = new BookDao("library");
        LoanDao loanDao = new LoanDao("library");

        //getting all books and members
        List<Member> members = memberDao.getAllMemebers();
        List<Book> books = bookDao.getAllBooks();
        String username = null;
        int memberType = 2;

        /* 2 - for non registered user 
        1 - form regular member
        0 - for admin
        -1 to stop application*/
        int menuOutput = 2;

        //non-registered user menu options
        while (menuOutput == 2) {

            displayMenuNormal();
            int choice = getChoiceNormal(input);   //whatever the user chooses
            String message = null;
            boolean sendMessage = true;

            switch (choice) {

                //User ends program
                case -1:

                    System.out.println("Program will exit in a moment");
                    menuOutput = -1;
                    break;

                //login member
                case 1:
                    input.nextLine();
                    System.out.println("Please enter your username:");
                    String tempUName = input.nextLine();

                    System.out.println("Please enter your password:");
                    String tempPsw = input.nextLine();

                    //check is user enterd valid details
                    if (memberDao.isMemberValid(tempUName, tempPsw)) {
                        System.out.println("Login successful!");
                        memberType = memberDao.getMemberType(tempUName);
                        if (memberType == 0) {
                            username = tempUName;
                            menuOutput = memberType;
                        } else if (memberType == 1) {
                            username = tempUName;
                            menuOutput = memberType;
                        }
                    } else {
                        System.out.println("Username or password is incorrect");
                    }
                    break;

                //register new member
                case 2:
                    if (!(memberType == 0 || memberType == 1)) {
                        Member m = new Member();

                        input.nextLine();
                        //getting information for username
                        System.out.println("Please enter new username");
                        String tmpUName = input.nextLine();
                        //check does user didnt left empty lines
                        if (!(memberDao.checkUsername(tmpUName)) || tmpUName == null || tmpUName == "") {
                            m.setUsername(tmpUName);
                        } else {
                            System.out.println("Username is not valid");
                            break;
                        }

                        //getting information for password
                        System.out.println("Please enter your password");
                        String tmpPsw = input.nextLine();
                        //check does user didnt left empty lines
                        if (!(tmpPsw == null || tmpPsw == "")) {
                            m.setPassword(tmpPsw);
                        } else {
                            System.out.println("Password is not valid");
                            break;
                        }

                        //getting information for first name
                        System.out.println("Please enter your first name");
                        String tmpFirstName = input.nextLine();
                        //check does user didnt left empty lines
                        if (!(tmpFirstName == null || tmpFirstName == "")) {
                            m.setFirstName(tmpFirstName);
                        } else {
                            System.out.println("First name is not valid");
                            break;
                        }

                        //getting information for last name
                        System.out.println("Please enter your last name");
                        String tmpLastName = input.nextLine();
                        //check does user didnt left empty lines
                        if (!(tmpLastName == null || tmpLastName == "")) {
                            m.setLastName(tmpLastName);
                        } else {
                            System.out.println("Last name is not valid");
                            break;
                        }

                        boolean confirmation = memberDao.registerMemeber(m);
                        if (confirmation) {
                            System.out.println("Congratulations you have been added");
                        }
                    }
                    menuOutput = 2; // register goes here
                    break;

                //display all books in library
                case 3:
                    System.out.println("****************** All Books In Stock*****************");
                    ArrayList<Book> stockEntries = bookDao.getAllBooks();
                    if (!stockEntries.isEmpty()) {
                        for (Book b : stockEntries) {
                            System.out.println(b);
                        }
                    } else {
                        System.out.println("No matches found!");
                    }
                    sendMessage = false;
                    break;
            }

        }

        //admin options
        while (menuOutput == 0) {

            displayMenuAdmin();
            int userChoice = getChoiceAdmin(input);   //whatever the admin chooses

            //switch depending on user's choice
            switch (userChoice) {

                case -1:
                    //User ends program
                    System.out.println("Program will exit in a moment");
                    menuOutput = -1;
                    break;

                case 1:
                    System.out.println("****************** All Books In Stock*****************");
                    ArrayList<Book> stockEntries = bookDao.getAllBooks();
                    if (!stockEntries.isEmpty()) {
                        for (Book b : stockEntries) {
                            System.out.println(b);
                        }
                    } else {
                        System.out.println("No matches found!");
                    }
                    break;

                //display all active loans for member
                case 2:
                    System.out.println("Currently active loans for you");
                    List<Loan> activeLoans = loanDao.getActiveLoanForMemeber(username);
                    if (!(activeLoans.isEmpty())) {
                        for (Loan l : activeLoans) {
                            System.out.println(l);
                        }
                    } else {
                        System.out.println("No loans found");
                    }
                    break;

                //display all loans for a member since join date
                case 3:
                    System.out.println("All loans since you joined");
                    List<Loan> historyOfLoans = loanDao.getAllLoanSinceJoin(username);
                    if (!(historyOfLoans.isEmpty())) {
                        for (Loan l : historyOfLoans) {
                            System.out.println(l);
                        }
                    } else {
                        System.out.println("No loans found");
                    }
                    break;

                //add new loan to the member
                case 4:
                    System.out.println("Please enter book ISBN number");
                    try {
                        int bookNo = input.nextInt();
                        boolean confirmation = loanDao.addNewLoan(bookNo, username);
                        if (confirmation) {
                            System.out.println("Loan was successful!");
                        } else {
                            System.out.println("Please check your details");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a number");
                    }
                    break;

                //return book to the library
                case 5:
                    System.out.println("Please enter books ISBN number");
                    int bookNo = input.nextInt();
                    boolean confirmation = loanDao.returnBook(bookNo, username);
                    if (confirmation) {
                        System.out.println("Return was successful!");
                    }
                    break;

                //add new book to the library
                case 6:
                    Book b = new Book();
                    input.nextLine();

                    try {
                        System.out.println("Please enter book ISBN:");
                        int isbn = input.nextInt();
                        if (!(bookDao.doesBookExist(isbn))) {
                            b.setIsbn(isbn);
                        } else {
                            System.out.println("ISBN is not valid");
                            break;
                        }
                        input.nextLine();

                        System.out.println("Please enter book title");
                        String title = input.nextLine();
                        if (!(title.equalsIgnoreCase(null) || title.equalsIgnoreCase(""))) {
                            b.setTitle(title);
                        } else {
                            System.out.println("Title field cannot be empty");
                            break;
                        }

                        System.out.println("Please enter book author");
                        String author = input.nextLine();
                        if (!(author.equalsIgnoreCase(null) || author.equalsIgnoreCase(""))) {
                            b.setAuthor(author);
                        } else {
                            System.out.println("Author field cannot be empty");
                            break;
                        }

                        System.out.println("Please enter book language");
                        String language = input.nextLine();
                        if (!(language.equalsIgnoreCase(null) || language.equalsIgnoreCase(""))) {
                            b.setBookLanguage(language);
                        } else {
                            System.out.println("Language field cannot be empty");
                        }
                        input.nextLine();

                        System.out.println("Please enter available no. of copies");
                        int copies = input.nextInt();

                        System.out.println("Please enter available year of publication");
                        int year = input.nextInt();

                        boolean confirm = bookDao.addBook(b);
                        if (confirm) {
                            System.out.println("Book has been added");
                        } else {
                            System.out.println("Book has not been added");
                        }

                    } catch (InputMismatchException ime) {
                        System.out.println("Please use valid input for fields");
                    }
                    break;

                //update book quantity (increase or decrease)
                case 7:
                    input.nextLine();
                    System.out.println("Please enter book ISBN:");
                    bookNo = input.nextInt();
                    //check does book exist
                    if (bookDao.doesBookExist(bookNo)) {
                        System.out.println("Please enter amount to decrease or "
                                + "increase stock");
                        int amount = input.nextInt();
                        Book bk = bookDao.findBookByISBN(bookNo);

                        if (bookDao.updateBookStock(amount, bookNo)) {
                            System.out.println("Book stock successfuly updated");
                            break;
                        } else {
                            System.out.println("Error occured");
                            break;
                        }

                    } else {
                        System.out.println("There is no such a book with this "
                                + "ISBN");
                        break;
                    }

                //disbale existing member
                case 8:
                    System.out.println("Please enter member username:");
                    String delUsername = input.nextLine();
                    if (delUsername == "" || delUsername == null) {
                        if (memberDao.checkUsername(delUsername)
                                && memberDao.getMemberType(delUsername) != 0) {
                            boolean delConfirmation = memberDao.disableMember(delUsername);
                            if (delConfirmation) {
                                System.out.println("Member disabled");
                                break;
                            } else {
                                System.out.println("Member was not disabled");
                                break;
                            }
                        } else {
                            System.out.println("Member username was not correct "
                                    + "or Admin cannot be disabled");
                            break;
                        }
                    } else {
                        System.out.println("Username fields cannot be empty");
                    }
                    break;

                //logout
                case 9:
                    System.out.println("Goodbey");
                    menuOutput = 2;
                    break;

                default:
                    System.out.println("No choice was made");
                    menuOutput = 2;
            }
        }

        //registerd member
        while (menuOutput == 1) {

            displayMenuMemeber();
            int userChoice = getChoiceMember(input);   //whatever the user chooses

            //switch depending on user's choice
            switch (userChoice) {
                case 1:
                    System.out.println("****************** All Books In Stock*****************");
                    ArrayList<Book> stockEntries = bookDao.getAllBooks();
                    if (!stockEntries.isEmpty()) {
                        for (Book b : stockEntries) {
                            System.out.println(b);
                        }
                    } else {
                        System.out.println("No matches found!");
                    }
                    break;

                //display active loan for a member
                case 2:
                    System.out.println("Currently active loans for you");
                    List<Loan> activeLoans = loanDao.getActiveLoanForMemeber(username);
                    if (!(activeLoans.isEmpty())) {
                        for (Loan l : activeLoans) {
                            System.out.println(l.toString());
                        }
                    } else {
                        System.out.println("No loans found");
                    }
                    break;

                //display all loans since day memeber joined
                case 3:
                    System.out.println("All loans since you joined");
                    List<Loan> historyOfLoans = loanDao.getAllLoanSinceJoin(username);
                    if (!(historyOfLoans.isEmpty())) {
                        for (Loan l : historyOfLoans) {
                            System.out.println(l);
                        }
                    } else {
                        System.out.println("No loans found");
                    }
                    break;

                //get new loan
                case 4:
                    System.out.println("Please enter book ISBN number");
                    try {
                        int bookNo = input.nextInt();
                        boolean confirmation = loanDao.addNewLoan(bookNo, username);
                        if (confirmation) {
                            System.out.println("Loan was successful!");
                        } else {
                            System.out.println("Please check your details");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a number");
                    }
                    break;

                //return book to the library
                case 5:
                    System.out.println("Please enter books ISBN number");
                    int bookNo = input.nextInt();
                    boolean confirmation = loanDao.returnBook(bookNo, username);
                    if (confirmation) {
                        System.out.println("Return was successful!");
                    }
                    break;

                //exit application
                case 6:
                    //User ends program
                    System.out.println("Program will exit in a moment");
                    menuOutput = -1;
                    break;
            }
        }
    }

    public static void displayMenuNormal() {
        System.out.println("-----------------------------------------------------");
        System.out.println("this is the not logged in menu");
        System.out.println("1. Login to the library");
        System.out.println("2. Register as a new member");
        System.out.println("3. View the details of all books in the library");
        System.out.println("Enter -1  to end the program.");
        System.out.println("-----------------------------------------------------");
    }

    public static void displayMenuMemeber() {
        System.out.println("-----------------------------------------------------");
        System.out.println("this is the normal; user menu! ");
        System.out.println("1. View the details of all books in the library");
        System.out.println("2. View the details of all loans currently active for you");
        System.out.println("3. View the details of all loans you have made since joining the library");
        System.out.println("4. Borrow a copy of a book in the library");
        System.out.println("5. Return a book you currently hace on loan");
        System.out.println("6. Logging out");
        System.out.println("-----------------------------------------------------");
    }

    public static void displayMenuAdmin() {
        System.out.println("-----------------------------------------------------");
        System.out.println("THIS IS THE ADMIN MENU ");
        System.out.println("1. View the details of all books in the library");
        System.out.println("2. View the details of all loans currently active for you");
        System.out.println("3. View the details of all loans you have made since joining the library");
        System.out.println("4. Borrow a copy of a book in the library");
        System.out.println("5. Return a book you currently hace on loan");
        System.out.println("6. Add a book to the library");
        System.out.println("7. Increase or decrease the number of copies of a book");
        System.out.println("8. Disable a member from the library");
        System.out.println("9. Logging out");
        System.out.println("Enter -1  to end the program.");
        System.out.println("-----------------------------------------------------");
    }

    /**
     * Checks doe user input was valid
     *
     * @param input - int, user choice
     * @return int
     */
    public static int getChoiceNormal(Scanner input) {
        int choice = 0;
        boolean validNumber = false;
        while (!validNumber) {
            try {
                choice = input.nextInt();
                validNumber = true;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a number to choose a menu option!");
                System.out.println();
                input.nextLine();
                displayMenuNormal();
            }
        }
        return choice;
    }

    public static int getChoiceMember(Scanner input) {
        int choice = 0;
        boolean validNumber = false;
        while (!validNumber) {
            try {
                choice = input.nextInt();
                validNumber = true;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a number to choose a menu option!");
                System.out.println();
                input.nextLine();
                displayMenuNormal();
            }
        }
        return choice;
    }

    public static int getChoiceAdmin(Scanner input) {
        int choice = 0;
        boolean validNumber = false;
        while (!validNumber) {
            try {
                choice = input.nextInt();
                validNumber = true;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a number to choose a menu option!");
                System.out.println();
                input.nextLine();
                displayMenuAdmin();
            }
        }
        return choice;
    }
}
