/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Address;
import DTO.Loan;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Audrius
 */
public class LoanDao extends Dao implements LoanDaoInterface {

    /**
     *
     * @param databaseName
     */
    public LoanDao(String databaseName) {
        super(databaseName);
    }

    /**
     * Gets all active loans for particular member.
     * @param username - String, member username
     * @return List<Address> - all active loans for that user
     */
    @Override
    public List<Loan> getActiveLoanForMemeber(String username) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Loan> activeLoans = new ArrayList();

        try {
            con = getConnection();
            String query = "SELECT * "
                    + "FROM loan "
                    + "WHERE username = ? "
                    + "AND loanStatus = 0";

            ps = con.prepareStatement(query);
            ps.setString(1, username);
            rs = ps.executeQuery();

            while (rs.next()) {
                int isbn = rs.getInt("ISBN");
                String uName = rs.getString("username");
                Date issueDate = rs.getDate("issueDate");

                Loan l = new Loan(isbn, uName, issueDate);
                activeLoans.add(l);

            }
        } catch (SQLException e) {
            System.out.println("Exception occured in "
                    + "getActiveLoanForMemeber method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of getActiveLoanForMemeber method: " + e.getMessage());
            }
        }
        return activeLoans;
    }

    /**
     * Gets all since join date loans for particular member.
     * @param username - String, member username
     * @return List<Address> - all loans for that user
     */
    @Override
    public List<Loan> getAllLoanSinceJoin(String username) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Loan> allLoans = new ArrayList();

        try {

            con = getConnection();
            String query = "SELECT * "
                    + "FROM loan "
                    + "WHERE username = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, username);
            rs = ps.executeQuery();

            while (rs.next()) {
                int isbn = rs.getInt("ISBN");
                String uName = rs.getString("username");
                Date issueDate = rs.getDate("issueDate");

                Loan l = new Loan(isbn, uName, issueDate);
                allLoans.add(l);
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in "
                    + "getAllLoanSinceJoin method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of getAllLoanSinceJoin method: " + e.getMessage());
            }
        }
        return allLoans;

    }

    /**
     * Return book where username and isbn match.
     * @param isbn - int, book isbn
     * @param username - String, member username 
     * @return boolean TRUE if returned or FALSE if not
     */
    @Override
    public boolean returnBook(int isbn, String username) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;

        try {
            con = getConnection();
            String query = "UPDATE loan "
                    + "SET loanStatus = 1 "
                    + "WHERE isbn = ? "
                    + "AND username = ?";

            ps = con.prepareStatement(query);
            ps.setInt(1, isbn);
            ps.setString(2, username);
            int result = ps.executeUpdate();

            if (result == 1) {
                confirmation = true;
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in "
                    + "returnBook method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of returnBook method: " + e.getMessage());
            }
        }
        return confirmation; 
    }

    /**
     * Add new loan for member.
     * @param isbn - int, book isbn
     * @param uName - String, member username 
     * @return boolean TRUE if added or FALSE if not
     */
    public boolean addNewLoan(int isbn, String uName) {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;
        
        try {
            
            con = getConnection();
            String query = "INSERT INTO loan(ISBN, username) "
                    + "VALUE (?, ?)";
            
            ps = con.prepareStatement(query);
            ps.setInt(1, isbn);
            ps.setString(2, uName);
            int result = ps.executeUpdate();
            
            if(result == 1){
                confirmation = true;
            }
            
        } catch (SQLException e) {
            System.out.println("Exception occured in the addNewLoan"
                    + " method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of the addNewLoan method: " + e.getMessage());
            }
        }
        return confirmation;
    }
    
    /**
     * Change userType, where isbn match and username match.
     * @param isbn - int, book isbn
     * @param uName - String, member username 
     * @return boolean TRUE if changed or FALSE if not
     */
    public boolean changeLoanStatus(int isbn, String uName){
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;

        try {
            con = getConnection();
            String query = "UPDATE loan "
                    + "SET returnDate = NULL "
                    + "WHERE isbn = ? "
                    + "AND username = ?";

            ps = con.prepareStatement(query);
            ps.setInt(1, isbn);
            ps.setString(2, uName);
            int result = ps.executeUpdate();

            if (result == 1) {
                confirmation = true;
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in "
                    + "returnBook method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of returnBook method: " + e.getMessage());
            }
        }
        return confirmation; 
    }   
}
