/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Member;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Audrius
 */
public class MemberDao extends Dao implements MemberDaoInterface {

    /**
     *
     * @param databaseName
     */
    public MemberDao(String databaseName) {
        super(databaseName);
    }

    /**
     * Gets all members from Member table of library database. 
     * @return List<Member> - all existing members
     */
    public List<Member> getAllMemebers() {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Member> result = new ArrayList();
        Member m = null;

        try {
            con = getConnection();
            String query = "SELECT * "
                    + "FROM member";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                String username = rs.getString("username");
                int userType = rs.getInt("userType");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                Date joinDate = rs.getDate("joinDate");
                String password = rs.getString("password");
                result.add(new Member(username, firstName, lastName, password,
                        userType, joinDate));
            }
        } catch (SQLException e) {
            System.out.println("Exception occured in the getAllMemebers"
                    + " method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of the getAllMemebers method: " + e.getMessage());
            }
        }
        return result;
    }

    /**
     * Check does Member username exist compared with username passed. 
     * @param uName - String, username
     * @return boolean TRUE if match or FALSE if not
     */
    public boolean checkUsername(String uName) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = true;

        try {
            con = getConnection();
            String query = "SELECT username "
                    + "FROM member "
                    + "WHERE username = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, uName);
            rs = ps.executeQuery();

            if (!(rs.next())) {
                confirmation = false;
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in "
                    + "checkUsername method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of checkUsername method: " + e.getMessage());
            }
        }

        return confirmation;
    }

    /**
     * Add new member details to member table. Username is unique, 
     * therefor it cannot be same.
     * @param m - Object of Member class
     * @return boolean TRUE if registered or FALSE if not
     */
    @Override
    public boolean registerMemeber(Member m) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;

        try {

            con = getConnection();
            String query = "INSERT INTO member(username, firstName, "
                    + "lastName, password)"
                    + "VALUES (?, ?, ?, ?)";

            ps = con.prepareStatement(query);
            ps.setString(1, m.getUsername());
            ps.setString(2, m.getFirstName());
            ps.setString(3, m.getLastName());
            ps.setString(4, m.getPassword());

            //executeUpdate is only for insert statement
            int result = ps.executeUpdate();
            if (result > 0) {
                confirmation = true;
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in the public boolean "
                    + "registerMember method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the public boolean addCustomer(Customer c) method: " + e.getMessage());
            }
        }
        return confirmation;
    }

    /**
     * Checks does passed password and username match member details in
     * Member table.
     * @param username - String, member username
     * @param password - String member password
     * @return boolean TRUE if match or FALSE if not
     */
    @Override
    public boolean isMemberValid(String username, String password) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;

        try {
            con = getConnection();
            String query = "SELECT username, password "
                    + "FROM member "
                    + "WHERE username = ? "
                    + "AND password = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();

            if (rs.next()) {
                confirmation = true;
            }
        } catch (SQLException e) {
            System.out.println("Exception occured in the public boolean "
                    + "isMemberValid method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of the public boolean isMemberValid method: "
                        + e.getMessage());
            }
        }
        return confirmation;
    }

    /**
     * Update existing member userType in Member table of Library database.
     * 0 = admin, 1 = regular member, 2 = not confirmed member
     * @param username - String, member username
     * @param n - int, type of the member
     * @return boolean TRUE if updated or FALSE if not
     */
    @Override
    public boolean changeUserType(String username, int n) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;

        try {
            con = getConnection();
            String query = "UPDATE member "
                    + "SET userType = ? "
                    + "WHERE username = ?";

            ps = con.prepareStatement(query);
            ps.setInt(1, n);
            ps.setString(2, username);
            int result = ps.executeUpdate();

            if (result == 1) {
                confirmation = true;
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in the changeUserType"
                    + " method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of the changeUserType method: " + e.getMessage());
            }
        }
        return confirmation;
    }

    /**
     * Gets member userType based on username passed. 
     * 0 = admin, 1 = regular member, 2 = not confirmed member
     * @param uName - String, member username
     * @return - int, type of the member
     */
    public int getMemberType(String uName) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int result = 2;

        try {

            con = getConnection();

            String query = "SELECT * "
                    + "FROM member "
                    + "WHERE username = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, uName);

            rs = ps.executeQuery();
            if (rs.next()) {
                result = rs.getInt("usertype");
            }
        } catch (SQLException e) {
            System.out.println("Exception occured in the public boolean "
                    + "getMemberType 1st method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of the public boolean getMemberType method: "
                        + e.getMessage());
            }
        }
        return result;
    }

    /**
     * Disable member, not allowing to login based on username passed. 
     * Change userType to 2.
     * @param username - String, member username
     * @return boolean TRUE if changed or FALSE if not
     */
    public boolean disableMember(String username) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean confirmation = false;

        try {
            con = getConnection();
            String query = "UPDATE member "
                    + "SET userType = 2 "
                    + "WHERE username = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, username);
            int result = ps.executeUpdate();

            if (result == 1) {
                confirmation = true;
            }

        } catch (SQLException e) {
            System.out.println("Exception occured in the disableMember"
                    + " method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section "
                        + "of the disableMember method: " + e.getMessage());
            }
        }
        return confirmation;
    }

    /**
     * Delete already existing member in Member table of Library database.
     * @param uName - String, member username
     * @return boolean TRUE if removed or FALSE if not
     */
    public boolean removeMemberByUsername(String uName) {

        Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;
        boolean confirm = false;

        try {
            con = getConnection();

            String query = "DELETE FROM member "
                    + "WHERE username = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uName);

            rowsAffected = ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("\tA problem occurred during the "
                    + "removeMemberByUsername method:");
            System.err.println("\t" + e.getMessage());
            rowsAffected = 0;
            
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.err.println("A problem occured when closing down the "
                        + "removeMemberByUsername method:\n" + e.getMessage());
            }
        }
        if (rowsAffected > 0){
            confirm = true;
        }
        return confirm;
    }

}
