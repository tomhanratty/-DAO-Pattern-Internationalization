/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Address;
import java.util.List;

/**
 *
 * @author AhmedKhan
 */
public interface AddressDaoInterface {

    public List<Address> getAllAddress();

    public Address selectAddressByID(int id);

    public List<Address> selectAddressByCity(String cityName);

    public List<Address> selectAddressByCounty(String countyName);

    public List<Address> selectWhereCityMatchesCounty(String cityName, String countyName);

    public boolean addAddress(Address a);

    public int updateAddressLine1(int addressID, String newAddressLine);

    public boolean deleteAddress(String addressLine1);

}