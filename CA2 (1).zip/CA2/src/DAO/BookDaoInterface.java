/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Book;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public interface BookDaoInterface {
    
          //Get all Books matching the supplied title exactly
   public ArrayList<Book> getAllBooks(); 
        //Get all Books matching the supplied title exactly
   public ArrayList<Book> selectBookByTitle(String title); 
   
   //Get all Books with a Book title containing the supplied text
   public ArrayList<Book> selectBooksContainingTitle(String title);
   
   //Get the Book matching the specified ISDN number
   public Book findBookByISBN(int isbn);
   
   //Add the supplied Book object to the database (return true if successful & false
    //otherwise). Remember that when you do an insert, you need an extra catch!
   public boolean addBook(Book b);
   
   //update the number of copies of a book that are available
   public boolean updateBookStock(int newstock,int isbn);
   
   //DELETE a book given its ISBN
   public boolean deleteBook(int isbn);
    
}
