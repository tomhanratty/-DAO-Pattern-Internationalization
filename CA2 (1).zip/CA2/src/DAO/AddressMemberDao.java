/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Ahmed
 */
public class AddressMemberDao extends Dao implements AddressMemberDaoInterface {

    /**
     *
     * @param dbName
     */
    public AddressMemberDao(String dbName) {
        super(dbName);
    }

    /**
     * Add new address details related of member to AddressMember table.
     * @param username - String, username
     * @param addressID - int, address id number
     * @return boolean TRUE if added or FALSE if not
     */
    @Override
    public boolean AddAddressMember(String username, int addressID) {
        Connection con = null;
        PreparedStatement ps = null;
        int rs = 0;

        try {
            con = getConnection();
            String query = "INSERT INTO member/address VALUES(?,?)";
            ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setInt(2, addressID);

            rs = ps.executeUpdate();
            if (rs > 0) {
                System.out.println("Member/Address Record has been Inserted");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Exception occured in  the AddAddressMember() method: " + e.getMessage());
        } finally {
            try {

                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the addGenreBook() method: " + e.getMessage());
            }
        }
        return false;
    }

    /**
     * Update existing address details related of member in AddressMember
     * table of Library database.
     * @param username - String, username
     * @param addressID - int, address id number
     * @return boolean TRUE if updated or FALSE if not
     */
    @Override
    public boolean updateAddressMemberUname(String username, int addressID) {
        Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;
        boolean changed = false;

        try {
            con = getConnection();

            String query = "UPDATE member/address SET username = ? WHERE addressID = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setInt(2, addressID);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Exception occured in the updateAddressMemberUname() method: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the updateAddressMemberUname() method");
                e.getMessage();
            }
        }
        if (rowsAffected > 0) {
            changed = true;
        }
        return changed;
    }

    /**
     * Delete already existing address details related to the member in Address
     * table of Library database.
     * @param username - String, username
     * @param addressID - int, address id number
     * @return boolean TRUE if deleted or FALSE if not
     */
    @Override
    public boolean deleteAddressMember(String username, int addressID) {
        Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;
        boolean changed = false;

        try {
            con = getConnection();

            String query = "DELETE FROM address/member WHERE username = ? AND addressID = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setInt(2, addressID);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Exception occured in the deleteAddressMember() method: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the deleteAddressMember() method");
                e.getMessage();
            }
        }
        if (rowsAffected > 0) {
            changed = true;
        }
        return changed;
    }
}
