/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Member;

/**
 *
 * @author Audrius
 */
public interface MemberDaoInterface {
    
    public boolean registerMemeber(Member m);
    public boolean isMemberValid(String username, String password);
    public boolean changeUserType(String username, int n);
    
}
