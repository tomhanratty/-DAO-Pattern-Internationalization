/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Book;
import DTO.Genre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public class GenreDao extends Dao implements GenreDaoInterface {

    /**
     *
     * @param databaseName
     */
    public GenreDao(String databaseName) {
        super(databaseName);
    }

    /**
     * gets all genres from the genre table
     * @return arraylist of genres
     */
    @Override
    public ArrayList<Genre> selectAllGenres() {
        //required for DB interaction
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        //required for data storage 
        ArrayList<Genre> genres = new ArrayList();

        try {
            con = getConnection();
            // make query
            String query = "SELECT * FROM genre";
            //complie into SQL
            ps = con.prepareStatement(query);
            //execute the SQL
            rs = ps.executeQuery();

            while (rs.next()) {

                int genreID = rs.getInt("genreID");
                String genreName = rs.getString("genreName");

                Genre g = new Genre(genreID, genreName);

                genres.add(g);

            }
        } catch (SQLException ex) {
            System.out.println("an exception occured while querying the genre table in the selectAllGenres() method" + ex.getMessage());
        } //shut down connection 
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the selectAllGenres() method: " + e.getMessage());
            }
        }

        return genres;
    }

    /**
     *  selects all genres partially matching the given word
     * @param word - String 
     * @return arraylist of Genres that contain the word
     */
    @Override
    public ArrayList<Genre> selectGenreContainingWord(String word) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Genre> genres = new ArrayList();

        try {
            con = getConnection();

            String query = "Select * from genre WHERE genreName LIKE ?";
            ps = con.prepareStatement(query);
            ps.setString(1, "%" + word + "%");
            rs = ps.executeQuery();

            while (rs.next()) {
                Genre g = new Genre(rs.getInt("genreID"), rs.getString("genreName"));
                genres.add(g);
            }
        } catch (SQLException e) {
            System.out.println("Exception occured in the selectGenreContainingWord() method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the selectGenreContainingWord() method: " + e.getMessage());
            }
        }
        return genres;
    }

    /**
     *  find a genre based on the given ID
     * @param id int
     * @return the matching Genre object
     */
    @Override
    public Genre findGenreById(int id) {
      Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Genre g = null;
        
        try{
            con = getConnection();

            String query = "Select * from genre where genreID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery(); 
            
            if(rs.next())
            {
               g = new Genre(rs.getInt("genreID"), rs.getString("genreName"));
            }
        }catch (SQLException e) {
            System.out.println("Exception occured in the findGenreById() method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the findGenreById() method: " + e.getMessage());
            }
        }
        return g;
    }

    /**
     * adds a genre to the genre table.
     * @param g - the genre to added
     * @return true is added , false otherwise
     */
    @Override
    public boolean addGenre(Genre g) {
    Connection con = null;
        PreparedStatement ps = null;
        int rs = 0;
        
        try{
            con = getConnection();
            String query = "INSERT INTO genre VALUES(?,?)";
            ps = con.prepareStatement(query);
            ps.setInt(1, g.getGenreID());
            ps.setString(2, g.getGenreName());
          
            rs = ps.executeUpdate(); 
            if(rs >0){
                System.out.println("Genre has been added");
                return true;
            }
        }catch (SQLException e){
            System.out.println("Exception occured in  the addGenre() method: " + e.getMessage());
         }
        finally{
            try {
                
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the addGenre() method: " + e.getMessage());
            }
        }
        return false;  
    }

    /**
     * deletes the genre with the given id
     * @param id int 
     * @return true is completed , false otherwise
     */
    @Override
    public boolean delteGenre(int id) {
       Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;
        boolean changed = false;

        try {
            con = getConnection();

            String query = "DELETE FROM genre WHERE genreID=?";

            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Exception occured in the delteGenre() method: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the delteGenre() method");
                e.getMessage();
            }
        }
        if(rowsAffected>0){
            changed = true;
        }
        return changed;
    }

}
