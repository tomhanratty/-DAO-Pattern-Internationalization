/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Address;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 
 * @author AhmedKhan
 */
public class AddressDao extends Dao implements AddressDaoInterface {

    /**
     *
     * @param databaseName
     */
    public AddressDao(String databaseName) {
        super(databaseName);
    }

    /**
     * Return all address information from Address table of library database.
     * @return List<Address> - all existing products of Address
     */
    @Override
    public List<Address> getAllAddress() {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Address> address = new ArrayList();

        try {
            con = getConnection();
            String query = "SELECT * FROM address";

            ps = con.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                int addressID = rs.getInt("addressID");
                String addressLine1 = rs.getString("addressLine1");
                String addressLine2 = rs.getString("addressLine2");
                String city = rs.getString("city");
                String county = rs.getString("county");
                String country = rs.getString("country");

                Address a1 = new Address(addressID, addressLine1, addressLine2, city, county, country);
                address.add(a1);
            }

        } catch (SQLException ex) {
            System.out.println("Exception occured in the getAllAddress() method: " + ex.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AddressDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AddressDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (con != null) {
                freeConnection(con);
            }
        }
        return address;
    }

    /**
     * Gets information of address based on passed ID.
     * @param id - int, address ID
     * @return Address - single object of found address
     */
    @Override
    public Address selectAddressByID(int id) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Address address = null;

        try {
            con = getConnection();
            String query = "SELECT * FROM address WHERE addressID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {

                address = new Address(rs.getInt("addressID"), rs.getString("addressLine1"), rs.getString("addressLine2"), rs.getString("city"), rs.getString("county"), rs.getString("country"));

            }

        } catch (SQLException ex) {
            System.out.println("Exception occured in the selectAddressByID() method: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException ex) {
                System.out.println("Exception occured in the finally section of the selectCustomersByName() method: " + ex.getMessage());
            }
        }
        return address;
    }

    /**
     * Gets all addresses based on passed city name.
     * @param cityName - String, city name
     * @return List<Address>
     */
    @Override
    public List<Address> selectAddressByCity(String cityName) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Address> address = new ArrayList();

        try {
            con = getConnection();
            String query = "SELECT * FROM address WHERE city = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, cityName);
            rs = ps.executeQuery();

            while (rs.next()) {
                int addressID = rs.getInt("addressID");
                String addressLine1 = rs.getString("addressLine1");
                String addressLine2 = rs.getString("addressLine2");
                String city = rs.getString("city");
                String county = rs.getString("county");
                String country = rs.getString("country");

                Address a1 = new Address(addressID, addressLine1, addressLine2, city, county, country);
                address.add(a1);
            }

        } catch (SQLException ex) {
            System.out.println("Exception occured in the selectAddressByID() method: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException ex) {
                System.out.println("Exception occured in the finally section of the selectCustomersByName() method: " + ex.getMessage());
            }
        }
        return address;
    }

    /**
     * Gets all addresses based on passed county name.
     * @param countyName - String, county name
     * @return List<Address> 
     */
    @Override
    public List<Address> selectAddressByCounty(String countyName) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Address> address = new ArrayList();

        try {
            con = getConnection();
            String query = "SELECT * FROM address WHERE county = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, countyName);
            rs = ps.executeQuery();

            while (rs.next()) {
                int addressID = rs.getInt("addressID");
                String addressLine1 = rs.getString("addressLine1");
                String addressLine2 = rs.getString("addressLine2");
                String city = rs.getString("city");
                String county = rs.getString("county");
                String country = rs.getString("country");

                Address a1 = new Address(addressID, addressLine1, addressLine2, city, county, country);
                address.add(a1);
            }

        } catch (SQLException ex) {
            System.out.println("Exception occured in the selectAddressByID() method: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException ex) {
                System.out.println("Exception occured in the finally section of the selectCustomersByName() method: " + ex.getMessage());
            }
        }
        return address;
    }

    /**
     * Gets all addresses based on city and county.
     * @param cityName - String, city name
     * @param countyName - String, county name
     * @return List<Address> 
     */
    @Override
    public List<Address> selectWhereCityMatchesCounty(String cityName, String countyName) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Address> address = new ArrayList();

        try {
            con = getConnection();
            String query = "SELECT * FROM address WHERE city = ? AND county = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, cityName);
            ps.setString(2, countyName);
            rs = ps.executeQuery();

            while (rs.next()) {
                int addressID = rs.getInt("addressID");
                String addressLine1 = rs.getString("addressLine1");
                String addressLine2 = rs.getString("addressLine2");
                String city = rs.getString("city");
                String county = rs.getString("county");
                String country = rs.getString("country");

                Address a1 = new Address(addressID, addressLine1, addressLine2, city, county, country);
                address.add(a1);
            }

        } catch (SQLException ex) {
            System.out.println("Exception occured in the selectAddressByID() method: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException ex) {
                System.out.println("Exception occured in the finally section of the selectCustomersByName() method: " + ex.getMessage());
            }
        }
        return address;
    }

    /**
     * Add new address details to Address table. adddressLine1 is unique, 
     * therefor it cannot be same.
     * @param a - Object of Address class
     * @return boolean TRUE if added or FALSE if not
     */
    @Override
    public boolean addAddress(Address a) {
        Connection con = null;
        PreparedStatement ps = null;
        int rs = 0;

        try {
            con = getConnection();
            String query = "INSERT INTO address VALUES (NULL, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(query);
            ps.setString(1, a.getAddressLine1());
            ps.setString(2, a.getAddressLine2());
            ps.setString(3, a.getCity());
            ps.setString(4, a.getCounty());
            ps.setString(5, a.getCountry());
            rs = ps.executeUpdate();

            if (rs > 0) {
                System.out.println("Title has been added ");
                return true;
            }

        } catch (SQLException ex) {
            System.out.println("Exception occured in the selectAddressByID() method: " + ex.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException ex) {
                System.out.println("Exception occured in the finally section of the selectCustomersByName() method: " + ex.getMessage());
            }
        }
        return false;
    }

    /**
     * Update existing address in Address table of Library database.
     * @param addressID - int, address id number
     * @param newAddressLine - String, 1st line of address
     * @return - int, number of effected rows
     */
    @Override
    public int updateAddressLine1(int addressID, String newAddressLine) {
        Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            con = getConnection();

            String query = "UPDATE address SET addressLine1 = ? WHERE addressID = ?";

            ps = con.prepareStatement(query);
            ps.setString(1, newAddressLine);
            ps.setInt(2, addressID);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Exception occured in the updateAddressLine1() method: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the updateProductName() method");
                e.getMessage();
            }
        }

        return rowsAffected;
    }

    /**
     * Delete already existing address in Address table of Library database.
     * @param addressLine1 - String, 1st line of address
     * @return boolean TRUE if deleted or FALSE if not
     */
    @Override
    public boolean deleteAddress(String addressLine1) {
        Connection con = null;
        PreparedStatement ps = null;
        int rs = 0;

        try {
            con = getConnection();
            String query = "DELETE FROM address WHERE addressID = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, addressLine1);

            rs = ps.executeUpdate();
            if (rs > 0) {
                System.out.println("Title has been deleted successfully");
                return true;

            }
        } catch (SQLException ex) {
            System.out.println("Exception occured in the selectAddressByID() method: " + ex.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException ex) {
                System.out.println("Exception occured in the finally section of the selectCustomersByName() method: " + ex.getMessage());
            }
        }
        return false;
    }
    
}
