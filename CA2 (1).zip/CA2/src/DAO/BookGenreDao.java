/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Book;
import DTO.Genre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Tom
 */
public class BookGenreDao extends Dao implements BookGenreInterface {

    /**
     *
     * @param databaseName
     */
    public BookGenreDao(String databaseName) {
        super(databaseName);
    }

    /**
     * adds a b//genre to the table
     * @param genreID int
     * @param isbn int
     * @return true if added , false if not
     */
    @Override
    public boolean addGenreBook(int genreID,int  isbn) {
    Connection con = null;
        PreparedStatement ps = null;
        int rs = 0;
        
        try{
            con = getConnection();
            String query = "INSERT INTO book/genre VALUES(?,?)";
            ps = con.prepareStatement(query);
            ps.setInt(1, genreID);
            ps.setInt(2, isbn);
            
            rs = ps.executeUpdate(); 
            if(rs >0){
                System.out.println("Book/Genre has been added");
                return true;
            }
        }catch (SQLException e){
            System.out.println("Exception occured in  the addGenreBook() method: " + e.getMessage());
         }
        finally{
            try {
                
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the addGenreBook() method: " + e.getMessage());
            }
        }
        return false;
    }

    /**
     * sets the genreID of a given book isbn
     * @param genreID int 
     * @param isbn int 
     * @return true is completed , false if not
     */
    @Override
    public boolean updateBookGenre(int genreID, int isbn) {
        Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;
        boolean changed = false;

        try {
            con = getConnection();

            String query = "UPDATE genre/book SET genreID = ? WHERE isbn = ?";

            ps = con.prepareStatement(query);
            ps.setInt(1, genreID);
            ps.setInt(2, isbn);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Exception occured in the updateBookGenre() method: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the updateBookGenre() method");
                e.getMessage();
            }
        }
        if(rowsAffected>0){
            changed = true;
        }
        return changed;
    }

    /**
     * delete a book/genre from the table
     * @param genreID int
     * @param isbn int
     * @return true if deleted , false otherwise
     */
    @Override
    public boolean deleteBookGenre(int genreID, int isbn) {
        Connection con = null;
        PreparedStatement ps = null;
        int rowsAffected = 0;
        boolean changed = false;

        try {
            con = getConnection();

            String query = "DELETE FROM genre/book WHERE genreID = ? AND ISBN = ?";

            ps = con.prepareStatement(query);
            ps.setInt(1, genreID);
            ps.setInt(2, isbn);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Exception occured in the deleteBookGenre() method: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the deleteBookGenre() method");
                e.getMessage();
            }
        }
        if(rowsAffected>0){
            changed = true;
        }
        return changed;
    }


}
