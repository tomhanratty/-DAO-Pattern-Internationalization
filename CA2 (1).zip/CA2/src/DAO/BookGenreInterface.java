/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Book;
import DTO.Genre;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public interface BookGenreInterface {
  //Add the supplied Book object to the database (return true if successful & false
    //otherwise). Remember that when you do an insert, you need an extra catch!


   public boolean addGenreBook(int genreID,int isbn); 
   
   //update the genre of a book (return true if successful & false
    //otherwise)
   public boolean updateBookGenre(int genreID, int isbn);
   
   //delete and entry from the genre/book table (return true if successful & false
    //otherwise)
   public boolean deleteBookGenre(int genreID, int isbn);
}
