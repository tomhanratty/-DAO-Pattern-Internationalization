/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;


import DTO.Genre;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public interface GenreDaoInterface {
 
   //Get all Genres 
   public ArrayList<Genre> selectAllGenres(); 
   
   //Get all Books with a Book title containing the supplied text
   public ArrayList<Genre> selectGenreContainingWord(String word);
   
   //Get the genre matching the specified id number
   public Genre findGenreById(int id);
   
   //Add the supplied Genre object to the database (return true if successful & false
    //otherwise). Remember that when you do an insert, you need an extra catch!
   public boolean addGenre(Genre g);
   
   //delete a genre
   public boolean delteGenre(int id);
}
