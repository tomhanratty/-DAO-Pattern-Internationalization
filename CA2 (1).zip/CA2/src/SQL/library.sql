-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2018 at 11:44 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

drop database if exists library;
create database if not exists library;

use library;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `addressID` int(3) NOT NULL,
  `addressLine1` varchar(20) NOT NULL,
  `addressLine2` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `county` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`addressID`, `addressLine1`, `addressLine2`, `city`, `county`, `country`) VALUES
(1, '25 nothing street', 'fake avenue', 'dublin', 'dublin', 'ireland'),
(2, '2 st jims road', 'fake green', 'naas', 'kildare', 'ireland'),
(3, '60 mary street', 'north road', 'newbridge', 'kildare', 'ireland'),
(4, '25 mary south', 'north road', 'newbridge', 'kildare', 'ireland'),
(5, '221 strand road', 'bandon', 'cork', 'cork', 'ireland'),
(6, '12 bridge street', 'townparks', 'dundalk', 'louth', 'ireland');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `ISBN` int(13) NOT NULL,
  `title` varchar(128) NOT NULL,
  `bookLanguage` varchar(20) NOT NULL,
  `yearOfPublication` int(4) NOT NULL,
  `author` varchar(20) NOT NULL,
  `availableNoOfCopies` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`ISBN`, `title`, `bookLanguage`, `yearOfPublication`, `author`, `availableNoOfCopies`) VALUES
(235461256, 'Mr. Magic', 'Lithuanian', 2018, 'A. Senkus', 0),
(978031600, 'Consider Phlebas', 'english', 1986, 'Iain m.Banks', 20),
(978034581, '12 Rules for Life', 'english', 2018, 'Jordan B. Peterson', 30),
(978045145, 'Raft', 'english', 1900, 'Stephen Baxter', 5),
(978055358, 'A Dance with Dragons :A Song of Ice and Fire', 'english', 2013, 'George R. R. Martin', 30),
(978055359, 'A Game of Thrones :A Song of Ice and Fire, Book 1', 'english', 2011, 'George R. R. Martin', 30),
(978081251, 'The Eye of the World : The Wheel of Time, Book 1', 'english', 1990, 'Robert Jordan', 30),
(978147321, 'Xeelee: Vengeance', 'english', 2018, 'Stephen Baxter', 15),
(978150117, 'It: A Novel', 'english', 2017, 'steven king', 30);

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

CREATE TABLE `genre` (
  `genreID` int(2) NOT NULL,
  `genreName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`genreID`, `genreName`) VALUES
(1, 'Fiction'),
(2, 'Non-Fiction'),
(3, 'Horror'),
(4, 'Sci-fi'),
(5, 'Historical'),
(6, 'Autobiography'),
(7, 'Fantasy');

-- --------------------------------------------------------

--
-- Table structure for table `genre/book`
--

CREATE TABLE `genre/book` (
  `genreID` int(2) NOT NULL,
  `ISBN` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `genre/book`
--

INSERT INTO `genre/book` (`genreID`, `ISBN`) VALUES
(1, 978045145),
(2, 978034581),
(3, 978150117),
(4, 978031600),
(4, 978081251),
(4, 978147321),
(7, 978055358),
(7, 978055359);

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `ISBN` int(13) NOT NULL,
  `username` varchar(12) NOT NULL,
  `issueDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `returnDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `loanStatus` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`ISBN`, `username`, `issueDate`, `returnDate`, `loanStatus`) VALUES
(978034581, 'admin6162', '2018-10-26 21:42:20', NULL, 0),
(235461256, 'billybob', '2018-10-26 21:42:20', NULL, 0),
(978045145, 'johnjoe', '2018-08-13 23:00:00', '2018-10-11 11:18:34', 1),
(978081251, 'johnjoe', '2017-09-04 23:00:00', '2017-09-07 20:06:17', 1),
(978031600, 'maryp', '2018-07-10 23:00:00', '2018-10-13 20:06:25', 1),
(978045145, 'maryp', '2018-10-26 21:41:58', NULL, 0),
(235461256, 'senkutis666', '2018-10-26 21:41:22', NULL, 0),
(978147321, 'senkutis666', '2018-10-26 21:41:46', '2018-10-26 23:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `username` varchar(20) NOT NULL,
  `usertype` int(1) NOT NULL DEFAULT '1',
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `joinDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`username`, `usertype`, `firstName`, `lastName`, `joinDate`, `password`) VALUES
('admin6162', 0, 'claire', 'stephens', '2015-11-05 00:00:00', '61pass61pass'),
('billybob', 1, 'william', 'roberts', '2008-11-11 00:00:00', 'bobpass123'),
('johnjoe', 1, 'john', 'joseph', '2010-11-11 00:00:00', 'password321'),
('maryp', 1, 'mary', 'collins', '2012-04-10 23:00:00', 'marymarymary'),
('pienius', 2, 'kazkoks', 'nezinau', '2018-10-26 21:37:20', 'eminem'),
('senkutis666', 0, 'Audrius', 'Senkus', '2018-10-23 20:05:31', 'eminem');

-- --------------------------------------------------------

--
-- Table structure for table `member/address`
--

CREATE TABLE `member/address` (
  `username` varchar(20) NOT NULL,
  `addressID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member/address`
--

INSERT INTO `member/address` (`username`, `addressID`) VALUES
('admin6162', 1),
('billybob', 2),
('billybob', 3),
('johnjoe', 4),
('maryp', 5),
('maryp', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`addressID`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`ISBN`);

--
-- Indexes for table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`genreID`);

--
-- Indexes for table `genre/book`
--
ALTER TABLE `genre/book`
  ADD UNIQUE KEY `UC_genre` (`genreID`,`ISBN`),
  ADD KEY `ISBN` (`ISBN`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD UNIQUE KEY `UC_loan` (`username`,`ISBN`,`issueDate`),
  ADD KEY `ISBN` (`ISBN`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `member/address`
--
ALTER TABLE `member/address`
  ADD UNIQUE KEY `UC_memberAddress` (`username`,`addressID`),
  ADD KEY `addressID` (`addressID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `addressID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `genre`
--
ALTER TABLE `genre`
  MODIFY `genreID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `genre/book`
--
ALTER TABLE `genre/book`
  ADD CONSTRAINT `genre/book_ibfk_1` FOREIGN KEY (`genreID`) REFERENCES `genre` (`genreID`),
  ADD CONSTRAINT `genre/book_ibfk_2` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`);

--
-- Constraints for table `loan`
--
ALTER TABLE `loan`
  ADD CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`username`) REFERENCES `member` (`username`),
  ADD CONSTRAINT `loan_ibfk_2` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`);

--
-- Constraints for table `member/address`
--
ALTER TABLE `member/address`
  ADD CONSTRAINT `member/address_ibfk_1` FOREIGN KEY (`username`) REFERENCES `member` (`username`),
  ADD CONSTRAINT `member/address_ibfk_2` FOREIGN KEY (`addressID`) REFERENCES `address` (`addressID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
