/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

/**
 *
 * @author Tom
 */
public class Book {
    private int isbn;
    private String title;
    private String bookLanguage;
    
    private int yearOfPublication;
    private String author;
    private int availableNoOfCopies;

    public Book(){
        
    }
    public Book(int isbn, String title, String bookLanguage,  int yearOfPublication, String author, int availableNoOfCopies) {
        this.isbn = isbn;
        this.title = title;
        this.bookLanguage = bookLanguage;
        
        this.yearOfPublication = yearOfPublication;
        this.author = author;
        this.availableNoOfCopies = availableNoOfCopies;
    }
    
    //getters and setters

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isdn) {
        this.isbn = isdn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBookLanguage() {
        return bookLanguage;
    }

    public void setBookLanguage(String bookLanguage) {
        this.bookLanguage = bookLanguage;
    }

    public int getYearOfPublication() {
        return yearOfPublication;
    }

    public void setYearOfPublication(int yearOfPublication) {
        this.yearOfPublication = yearOfPublication;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getAvailableNoOfCopies() {
        return availableNoOfCopies;
    }

    public void setAvailableNoOfCopies(int availableNoOfCopies) {
        this.availableNoOfCopies = availableNoOfCopies;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + this.isbn;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Book other = (Book) obj;
        if (this.isbn != other.isbn) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Book{" + "isdn=" + isbn + ", title=" + title + ", bookLanguage=" + bookLanguage +  ", yearOfPublication=" + yearOfPublication + ", author=" + author + ", availableNoOfCopies=" + availableNoOfCopies + '}';
    }
    
    
    
    
    
}
