/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.util.Objects;

/**
 *
 * @author D00197085
 */
public class MemberAddress {
    
    /*
    username Memeber
    addressID Address
    */
    
    private String username;
    private int addressID;

    public MemberAddress() {
    }

    public MemberAddress(String username, int addressID) {
        this.username = username;
        this.addressID = addressID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getAddressID() {
        return addressID;
    }

    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.username);
        hash = 41 * hash + this.addressID;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MemberAddress other = (MemberAddress) obj;
        if (this.addressID != other.addressID) {
            return false;
        }
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "MemberAddress{" + "username=" + username + ", addressID=" + addressID + '}';
    }
    
}
