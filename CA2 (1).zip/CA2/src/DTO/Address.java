/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

/**
 *
 * @author Ahmed
 */
public class Address {
    /*
    addressID int
    addressLine1 varchar
    addressLine2 varchar
    city varchar
    county varchar
    country varchar
    */
    
    private int addressID;
    private String addressLine1, addressLine2, city, county, country;

    public Address() {
    }

    /**
     * 
     * @param addressID
     * @param addressLine1
     * @param addressLine2
     * @param city
     * @param county
     * @param country 
     */
    public Address(int addressID, String addressLine1, String addressLine2, String city, String county, String country) {
        this.addressID = addressID;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.county = county;
        this.country = country;
    }

    //setters and getters
    public int getAddressID() {
        return addressID;
    }
    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }
    public String getAddressLine1() {
        return addressLine1;
    }
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine2() {
        return addressLine2;
    }
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getCounty() {
        return county;
    }
    public void setCounty(String county) {
        this.county = county;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + this.addressID;
        return hash;
    }

    /**
     * Two adresses considered equal if there addressID are identical. 
     * @param obj
     * @return boolean expression of true or false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Address other = (Address) obj;
        if (this.addressID != other.addressID) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Address{" + "addressID=" + addressID + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", city=" + city + ", county=" + county + ", country=" + country + '}';
    }
    
    
    
}
