/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.util.Objects;

/**
 *
 * @author Tom
 */
public class Genre {
    
    private int genreID;
    private String genreName;

    public Genre() {
    }

    /**
     * 
     * @param genreID
     * @param genreName 
     */
    public Genre(int genreID, String genreName) {
        this.genreID = genreID;
        this.genreName = genreName;
    }

    //setters and getters
    public int getGenreID() {
        return genreID;
    }
    public void setGenreID(int genreID) {
        this.genreID = genreID;
    }
    public String getGenreName() {
        return genreName;
    }
    public void setGenreName(String genreName) {
        this.genreName = genreName;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.genreName);
        return hash;
    }

    /**
     * Two genres considered equal if there genreName are identical. 
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Genre other = (Genre) obj;
        if (!Objects.equals(this.genreName, other.genreName)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Genre{" + "genreID=" + genreID + 
                ", genreName=" + genreName + '}';
    }

    
    
    
    
}
