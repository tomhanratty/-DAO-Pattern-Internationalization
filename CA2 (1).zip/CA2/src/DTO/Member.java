/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author D00197085
 */
public class Member {
    /*
    username
    type
    firstName
    lastName
    joinDate
    password
    */
    
    //fields of the class
    private String username, firstName, lastName, password;
    private int type;
    private Date joinDate;

    
    public Member() {
    }
    
    /**
     * 
     * @param username
     * @param firstName
     * @param lastName
     * @param password
     * @param type
     * @param joinDate 
     */
    public Member(String username, String firstName, String lastName, 
            String password) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        
    }

    public Member(String username, String firstName, String lastName, 
            String password, int userType, Date joinDate){
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.type = userType;
        this.joinDate = joinDate;
    }
    
    //setters and getters
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }
    public Date getJoinDate() {
        return joinDate;
    }
    public void setJoinDate(Date joinDate) {
        this.joinDate = joinDate;
    }

    @Override
    public String toString() {
        return "Member{" + 
                ", username=" + username + 
                ", firstName=" + firstName + 
                ", lastName=" + lastName + 
                ", password=" + password + 
                ", type=" + type + 
                ", joinDate=" + joinDate + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 41 * hash + Objects.hashCode(this.username);
        return hash;
    }

    /**
     * Two members considered equal if there username are identical. 
     * @param obj
     * @return boolean expression of true or false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Member other = (Member) obj;
        if (this.username != other.username) {
            return false;
        }
        return true;
    }
    
    
    
}
