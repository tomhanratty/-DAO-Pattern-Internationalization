/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author D00197085
 */
public class Loan {
    /*
    isbn Book
    username Member
    issueDate date
    returnDate date
    loanStatus boolean
    */
    
    private int isbn;
    private String username;
    private Date issueDate, returnDate;

    public Loan() {
    }

    /**
     * 
     * @param isbn
     * @param username
     * @param issueDate
     */
    public Loan(int isbn, String username, Date issueDate) {
        this.isbn = isbn;
        this.username = username;
        this.issueDate = issueDate;
    }
    public Loan(int isbn, String username) {
        this.isbn = isbn;
        this.username = username;
    }
    

    public int getIsbn() {
        return isbn;
    }
    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public Date getIssueDate() {
        return issueDate;
    }
    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }
    public Date getReturnDate() {
        return returnDate;
    }
    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.isbn);
        hash = 37 * hash + Objects.hashCode(this.username);
        hash = 37 * hash + Objects.hashCode(this.issueDate);
        return hash;
    }

    /**
     * Loan considered equal if ISBN, username and issue date are the same.
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Loan other = (Loan) obj;
        if (!Objects.equals(this.isbn, other.isbn)) {
            return false;
        }
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.issueDate, other.issueDate)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Loan{" + "isbn=" + isbn + ", username=" + username + ", issueDate=" + issueDate + ", returnDate=" + returnDate + '}';
    }
    
    
    
    
}
