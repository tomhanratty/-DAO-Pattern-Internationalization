/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Loan;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author D00197085
 */
public class LoanDaoTest {
    private LoanDao loanDao;
    
    public LoanDaoTest() {
         //create MemberDao object to use throughout the test
        loanDao = new LoanDao("libraryTest");
    }

    /**
     * Test of getActiveLoanForMemeber method, of class LoanDao.
     */
    @Test
    public void testGetActiveLoanForMemeber() {
        System.out.println("getActiveLoanForMemeber");
        String username = "johnjoe";
        List<Loan> result = loanDao.getActiveLoanForMemeber(username);
        assertEquals(0, result.size());
    }
    
    /**
     * Test of getActiveLoanForMemeber method, of class LoanDao (Where no 
     * match found).
     */
    @Test
    public void testGetActiveLoanForMemeber_NoMatchFound() {
        System.out.println("getActiveLoanForMemeber");
        String username = "johnj";
        List<Loan> result = loanDao.getActiveLoanForMemeber(username);
        assertEquals(0, result.size());
    }

    /**
     * Test of getAllLoanSinceJoin method, of class LoanDao.
     */
    @Test
    public void testGetAllLoanSinceJoin() {
        System.out.println("getAllLoanSinceJoin");
        String username = "johnjoe";
        List<Loan> result = loanDao.getAllLoanSinceJoin(username);
        assertEquals(3, result.size());
    }
    
    /**
     * Test of getAllLoanSinceJoin method, of class LoanDao (Where no matches
     * was found).
     */
    @Test
    public void testGetAllLoanSinceJoin_NoMatches() {
        System.out.println("getAllLoanSinceJoin");
        String username = "johnjoe499";
        List<Loan> result = loanDao.getAllLoanSinceJoin(username);
        assertEquals(0, result.size());
    }

    /**
     * Test of returnBook method, of class LoanDao (Where no return
     * was made).
     */
    @Test
    public void testReturnBook_NoReturn() {
        System.out.println("returnBook_NoReturn");
        int isbn = 123456;
        String username = "testName";
        boolean expResult = false;
        boolean result = loanDao.returnBook(isbn, username);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of returnBook method, of class LoanDao.
     */
    @Test
    public void testReturnBook() {
        System.out.println("returnBook_NoReturn");
        int isbn = 978055358;
        String username = "johnjoe";
        boolean expResult = true;
        boolean result = loanDao.returnBook(isbn, username);
        assertEquals(expResult, result);
        if(result){
            System.out.println("Method returned appropriately, confirming "
                    + "database changed by trying to change loan status");
            boolean rowUpdate = loanDao.changeLoanStatus(isbn, username);
            assertEquals(rowUpdate, true);
        }
    }

    /**
     * Test of addNewLoan method, of class LoanDao.
     */
    @Test
    public void testAddNewLoan() {
        System.out.println("addNewLoan");
        int isbn = 978150117;
        String uName = "senkutis666";
        boolean expResult = true;
        boolean result = loanDao.addNewLoan(isbn, uName);
        assertEquals(expResult, result);
    }
    
}
