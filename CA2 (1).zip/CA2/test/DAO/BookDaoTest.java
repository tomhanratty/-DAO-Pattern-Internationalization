/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Book;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author Tom
 */
public class BookDaoTest {

    private static BookDao bookdao;

    public BookDaoTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        bookdao = new BookDao("library");
    }

    /**
     * Test of selectBookByTitle method, of class BookDao.
     */
    @Test
    public void testSelectBookByTitle() {
        String title = "Consider Phlebas";

        int NumBooksinTable = 1;

        ArrayList<Book> result = bookdao.selectBookByTitle(title);
        assertEquals(NumBooksinTable, result.size());

    }

    /**
     * Test of selectBooksContainingTitle method, of class BookDao.
     */
    @Test
    public void testSelectBooksContainingTitle() {
        String title = "Consider";

        int NumBooksinTable = 1;

        ArrayList<Book> result = bookdao.selectBooksContainingTitle(title);
        assertEquals(NumBooksinTable, result.size());
    }

    /**
     * Test of findBookByISDN method, of class BookDao.
     */
    @Test
    public void testFindBookByISBN() {
        int isbn = 978031600;

        Book expResult = new Book(978031600, "Consider Phlebas", "english", 1986, "Iain m.Banks", 20);
        Book result = bookdao.findBookByISBN(isbn);
        assertEquals(expResult, result);

    }

    /**
     * Test of getAllBooks method, of class BookDao.
     */
    @Test
    public void testGetAllBooks() {
        System.out.println("getAllBooks");

        int NumBooksinTable = 8;

        ArrayList<Book> expResult = null;
        ArrayList<Book> result = bookdao.getAllBooks();
        assertEquals(NumBooksinTable, result.size());

    }

    /**
     * Test of addBook method, of class BookDao.
     */
    @Test
    public void testAddBook() {
        System.out.println("addBook");
        Book b = new Book(1, "test", "test", 1986, "test", 20);
        boolean expResult = true;
        boolean result = bookdao.addBook(b);

         assertTrue((result));
         if(result){
              System.out.println("Method Returned appropriately, confirming database changed by trying to remove what was added");
              boolean deleted = bookdao.deleteBook(1);
              assertEquals(deleted, true);
         }

    }

    /**
     * Test of updateBookStock method, of class BookDao.
     */
    @Test
    public void testUpdateBookStock() {
        System.out.println("updateBookStock");
        int isbn = 978031600;
        int newStock = 50;

        boolean expResult = true;
        boolean result = bookdao.updateBookStock(50, 978031600);

        if (expResult == result) {
            Book expectedBook = new Book(978031600, "Consider Phlebas", "english", 1986, "Iain m.Banks", 50);
            Book resultBook = bookdao.findBookByISBN(978031600);

            assertEquals(resultBook, expectedBook);
        }

    }



    /**
     * Test of isBookExist method, of class BookDao.
     */
    @Test
    public void testdoesBookExist() {
        int testISBN = 978031600;

        boolean expResult = true;

        boolean result = bookdao.doesBookExist(testISBN);

        assertEquals(expResult, result);

    }

}
