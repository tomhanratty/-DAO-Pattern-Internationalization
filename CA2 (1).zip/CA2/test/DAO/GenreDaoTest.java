/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Book;
import DTO.Genre;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author D00197327
 */
public class GenreDaoTest {
    
    private static GenreDao genredao;
    
    public GenreDaoTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        genredao = new GenreDao("library");
    }
    /**
     * Test of selectAllGenres method, of class GenreDao.
     */
    @Test
    public void testSelectAllGenres() {
        System.out.println("get all books");
        
        int numGenresInTable = 7;
        
        ArrayList<Genre> expResult = null;
        ArrayList<Genre> result = genredao.selectAllGenres();
        assertEquals(numGenresInTable,result.size());
    }

    /**
     * Test of selectGenreContainingWord method, of class GenreDao.
     */
    @Test
    public void testSelectGenreContainingWord() {
        String genre = "Horror";

        int NumGenresinTable = 1;

        ArrayList<Genre> result = genredao.selectGenreContainingWord(genre);
        assertEquals(NumGenresinTable, result.size());
       
    }

    /**
     * Test of findGenreById method, of class GenreDao.
     */
    @Test
    public void testFindGenreById() {
        System.out.println("findGenreById");
        int id = 2;

        Genre expResult = new Genre(2, "Non-Fiction");
        Genre result = genredao.findGenreById(id);
        assertEquals(expResult, result);
    }

    /**
     * Test of addGenre method, of class GenreDao.
     */
    @Test
    public void testAddGenre() {
        System.out.println("addGenre");
        
        Book b = new Book(1, "test", "test", 1986, "test", 20);
        Genre g = new Genre(8,"dictionary");
        boolean expResult = true;
        boolean result = genredao.addGenre(g);

         assertTrue((result));
         if(result){
              System.out.println("Method Returned appropriately, confirming database changed by trying to remove what was added");
              boolean deleted = genredao.delteGenre(8);
              assertEquals(deleted, true);
         }
    }


    
}
