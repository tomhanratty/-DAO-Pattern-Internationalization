/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author Tom
 */
public class BookGenreDaoTest {
    private static BookGenreDao bookgenredao;
    public BookGenreDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        bookgenredao = new BookGenreDao("library");
    }

    /**
     * Test of addGenreBook method, of class BookGenreDao.
     */
    @Test
    public void testAddGenreBook() {
        System.out.println("addGenreBook");
        int isbn = 666;
        int  genreid = 99;
        boolean expResult = true;
        boolean result = bookgenredao.addGenreBook(genreid,isbn);
        
        
         if(result){
              System.out.println("Method Returned appropriately, confirming database changed by trying to remove what was added");
              boolean deleted = bookgenredao.deleteBookGenre(genreid,isbn);
              assertEquals(deleted, true);
         }
        
        
        
    }

    /**
     * Test of updateBookGenre method, of class BookGenreDao.
     */
    @Test
    public void testUpdateBookGenre() {
        System.out.println("updateBookStock");
        int isbn = 978031600;
        int genreID = 7;
        
        boolean expResult = true;
        boolean result = bookgenredao.updateBookGenre(genreID, isbn);
        
        if(expResult == result){
            boolean output = bookgenredao.updateBookGenre(4, isbn);
            
            assertEquals(output , true);
        }
       
        }


    
    
    
    
    
       
    }


    
