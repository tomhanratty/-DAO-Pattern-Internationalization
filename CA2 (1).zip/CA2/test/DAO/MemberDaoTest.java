/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Member;
import java.util.ArrayList;
import java.util.List;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Audrius
 */
public class MemberDaoTest {
    private MemberDao memberDao;
    
    public MemberDaoTest() {
        //create MemberDao object to use throughout the test
        memberDao = new MemberDao("libraryTest");
    }

    /**
     * Test of getMemberByUsername method, of class MemberDao.
     */
//    @Test
//    public void testGetMemberByUsername() {
//        System.out.println("getMemberByUsername");
//        String uName = "senkutis";
//        
//        Member m = new Member("senkutis666", "audrius", "senkus", "eminem");
//        List<Member> expResult = new ArrayList();
//        expResult.add(m);
//        
//        List<Member> result = memberDao.getMemberByUsername(uName);
//        System.out.println(result);
//        assertEquals(expResult, result);      
//    }

    /**
     * Test of getAllMemebers method, of class MemberDao.
     */
    @Test
    public void testGetAllMemebers() {
        System.out.println("getAllMemebers");
        //Run the get all members method
        List<Member> result = memberDao.getAllMemebers();
        //confirm that the number if member lines retrieved
        assertEquals(5, result.size());
    }

    /**
     * Test of checkUsername method, of class MemberDao.
     */
    @Test
    public void testCheckUsername() {
        System.out.println("checkUsername");
        String uName = "senkutis666";
        boolean expResult = true;
        boolean result = memberDao.checkUsername(uName);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of checkUsername method, of class MemberDao (Where no matches 
     * should be found).
     */
    @Test
    public void testCheckUsername_NoMatches() {
        System.out.println("checkUsername");
        String uName = "senkutis";
        boolean expResult = false;
        boolean result = memberDao.checkUsername(uName);
        assertEquals(expResult, result);
    }

    /**
     * Test of registerMemeber method, of class MemberDao.
     */
    @Test
    public void testRegisterMemeber() {
        System.out.println("registerMemeber (4 arguments)");
        String username = "TestUser", firstName = "Test1stName", 
                lastName = "Test2ndName", psw = "testPsw";
        Member m = new Member(username, firstName, lastName, psw);
        boolean expResult = true;
        boolean result = memberDao.registerMemeber(m);
        
        assertTrue(result);
        if(result){
            System.out.println("Method returned appropriately, confirming "
                    + "database changed by trying to remove what was added");
            boolean rowDeleted = memberDao.removeMemberByUsername(username);
            assertEquals(rowDeleted, true);
        }
    }

    /**
     * Test of isMemberValid method, of class MemberDao.
     */
    @Test
    public void testIsMemberValid() {
        System.out.println("isMemberValid");
        String username = "senkutis666";
        String password = "eminem";
        boolean expResult = true;
        boolean result = memberDao.isMemberValid(username, password);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of isMemberValid method, of class MemberDao (Where no matches 
     * was found).
     */
    @Test
    public void testIsMemberValid_NoMatches() {
        System.out.println("isMemberValid");
        String username = "senkuti";
        String password = "wrongPassword";
        boolean expResult = false;
        boolean result = memberDao.isMemberValid(username, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of changeUserType method, of class MemberDao.
     */
    @Test
    public void testChangeUserType() {
        System.out.println("changeUserType");
        String username = "billybob";
        int n = 2;
        boolean expResult = true;
        boolean result = memberDao.changeUserType(username, n);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of changeUserType method, of class MemberDao_NoCahnge (Where no 
     * changes was made).
     */
    @Test
    public void testChangeUserType_NoChange() {
        System.out.println("changeUserType_NoChange");
        String username = "Test";
        int n = 2;
        boolean expResult = false;
        boolean result = memberDao.changeUserType(username, n);
        assertEquals(expResult, result);
    }

    /**
     * Test of getMemberType method, of class MemberDao.
     */
    @Test
    public void testGetMemberType() {
        System.out.println("getMemberType");
        String uName = "senkutis666";
        int expResult = 1;
        int result = memberDao.getMemberType(uName);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of getMemberType method, of class MemberDao (Where no matches
     * was found).
     */
    @Test
    public void testGetMemberType_NoMatches() {
        System.out.println("getMemberType");
        String uName = "testName";
        int expResult = 2;
        int result = memberDao.getMemberType(uName);
        assertEquals(expResult, result);
    }

    /**
     * Test of disableMember method, of class MemberDao.
     */
    @Test
    public void testDisableMember() {
        System.out.println("disableMember");
        String username = "maryp";
        boolean expResult = true;
        boolean result = memberDao.disableMember(username);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of disableMember method, of class MemberDao (Where no changes was 
     * made).
     */
    @Test
    public void testDisableMember_NoChanges() {
        System.out.println("disableMember");
        String username = "mary";
        boolean expResult = false;
        boolean result = memberDao.disableMember(username);
        assertEquals(expResult, result);
    }

    /**
     * Test of removeMemberByUsername method, of class MemberDao.
     */
    @Test
    public void testRemoveMemberByUsername() {
        System.out.println("removeMemberByUsername");
        String uName = "";
        MemberDao instance = null;
        boolean expResult = false;
        boolean result = instance.removeMemberByUsername(uName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
