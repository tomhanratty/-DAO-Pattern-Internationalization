/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.MemberAddress;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author D00191429
 */
public class AddressMemberDaoTest {

    private AddressMemberDao addressDao;

    public AddressMemberDaoTest() {
        // Create a addresskDao object to use throughout the tests
        addressDao = new AddressMemberDao("libraryTest");
    }

    /**
     * Test of AddAddressMember method, of class AddressMemberDao.
     */
    @Test
    public void testAddAddressMember() {
        System.out.println("AddAddressMember");
        String name = "faker";
        int id = 3;
        boolean result = addressDao.AddAddressMember(name, id);

        if (result) {
            System.out.println("Method Returned appropriately, confirming database changed by trying to remove what was added");
            boolean deleted = addressDao.deleteAddressMember(name, id);
            assertEquals(deleted, result);
        }
    }

    /**
     * Test of updateAddressMemberUname method, of class AddressMemberDao.
     */
    @Test
    public void testUpdateAddressMemberUname() {
        System.out.println("updateAddressMemberUname");

        String tst = "Tester";
        int id = 3;

        int expResult = 1;
        boolean result = addressDao.updateAddressMemberUname(tst, id);

        if (result) {
            MemberAddress expectedProd = new MemberAddress("testReycord1", 1);
        }
    }

}
