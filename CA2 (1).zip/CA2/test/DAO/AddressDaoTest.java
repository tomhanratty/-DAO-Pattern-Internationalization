/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Address;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ahmed
 */
public class AddressDaoTest {

    private AddressDao addressDao;

    public AddressDaoTest() {
        // Create a addresskDao object to use throughout the tests
        addressDao = new AddressDao("libraryTest");
    }

    /**
     * Test of getAllAddress method, of class AddressDao.
     */
    @Test
    public void testGetAllAddress() {
        System.out.println("getAllAddress");
        List<Address> result = addressDao.getAllAddress();
        int numProductsInTable = 6;
        assertEquals(numProductsInTable, result.size()
        );

    }

    /**
     * Test of selectAddressByID method, of class AddressDao.
     */
    @Test
    public void testSelectAddressByID() {
        System.out.println("selectAddressByID");
        int id = 4;
        Address expResult = new Address(id, "testAddress", "testaddress", "dublin", "dundalk", "Ireland");
        Address result = addressDao.selectAddressByID(id);
        assertEquals(expResult, result);

    }

    /**
     * Test of selectAddressByCity method, of class AddressDao.
     */
    @Test
    public void testSelectAddressByCity() {
        System.out.println("selectAddressByCity");
        String city = "newbridge";
        int numberOfValues = 2;
        List<Address> result = addressDao.selectAddressByCity(city);
        assertEquals(numberOfValues, result.size());
    }

    /**
     * Test of selectAddressByCounty method, of class AddressDao.
     */
    @Test
    public void testSelectAddressByCounty() {
        System.out.println("selectAddressByCounty");
        String city = "kildare";
        int numberOfValues = 3;
        List<Address> result = addressDao.selectAddressByCounty(city);
        assertEquals(numberOfValues, result.size());
    }

    /**
     * Test of selectWhereCityMatchesCounty method, of class AddressDao.
     */
    @Test
    public void testSelectWhereCityMatchesCounty() {
        System.out.println("selectWhereCityMatchesCounty");
        String cityName = "dublin";
        String countyName = "dublin";
        int expResult = 1;
        List<Address> result = addressDao.selectWhereCityMatchesCounty(cityName, countyName);
        assertEquals(expResult, result.size());
    }

    /**
     * Test of addAddress method, of class AddressDao.
     */
    @Test
    public void testAddAddress() {
        System.out.println("addAddress");
        Address a = new Address(10, "fake2", "fake2", "fake2", "fake2", "fake2");
        boolean result = addressDao.addAddress(a);
        assertTrue((result));
        
        if (result) {
            System.out.println("Method Returned appropriately, confirming database changed by trying to remove what was added");
            boolean deleted = addressDao.deleteAddress("fake2");
            assertEquals(deleted, true);
        }
    }
    /**
     * Test of updateAddressLine1 method, of class AddressDao.
     */
    @Test
    public void testUpdateAddressLine1() {
        System.out.println("updateAddressLine1");

        int id = 3;
        String tst = "Tester";

        int expResult = 1;
        int result = addressDao.updateAddressLine1(id, tst);

        assertEquals(expResult, result);

        if (expResult == result) {
            Address expectedProd = new Address(3, "fakeAddress", "fakeAddress", "fakeAddress", "fakeAddress", "fakeAddress");
            Address resultProd = addressDao.selectAddressByID(id);
            assertEquals(resultProd, expectedProd);
            addressDao.updateAddressLine1(id, "FAKEST ADDRESS");
        }
    }

    
}


